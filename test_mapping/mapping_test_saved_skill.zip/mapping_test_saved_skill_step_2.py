# mapping_test_saved_skill step 2

def transform(ctx):
    adj = ctx.book("expected_adjustments.xlsx")
    out = ctx.book("expected_output.xlsx")
    adj_rows = adj.read("AdjustData", "A2:B5")
    adjustments = {}
    for row in adj_rows:
        if row and row[0] not in (None, ""):
            adjustments[str(row[0])] = row[1] if len(row) > 1 and isinstance(row[1], (int, float)) else 0
    base_rows = out.read("ResultSheet", "A2:E5")
    write_rows = []
    for row in base_rows:
        code = str(row[0]) if row and row[0] not in (None, "") else ""
        base_amount = row[4] if len(row) > 4 and isinstance(row[4], (int, float)) else 0
        adjustment = adjustments.get(code, 0)
        write_rows.append([adjustment, base_amount + adjustment])
    out.write("ResultSheet", "F2", write_rows)
