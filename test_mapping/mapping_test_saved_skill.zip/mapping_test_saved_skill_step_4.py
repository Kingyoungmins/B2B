# mapping_test_saved_skill step 4

def transform(ctx):
    out = ctx.book("expected_output.xlsx")
    rows = out.read("ResultSheet", "A2:H5")
    try:
        out.add_sheet("Validation_Result")
    except Exception:
        pass
    total = 0
    filled = 0
    for row in rows:
        if row and row[0] not in (None, ""):
            filled += 1
        if len(row) > 6 and isinstance(row[6], (int, float)):
            total += row[6]
    out.write("Validation_Result", "A1", [["Check", "Value"], ["Rows", filled], ["FinalAmountTotal", total]])
