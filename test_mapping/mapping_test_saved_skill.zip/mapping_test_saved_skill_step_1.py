# mapping_test_saved_skill step 1

def transform(ctx):
    sales = ctx.book("expected_sales.xlsx")
    out = ctx.book("expected_output.xlsx")
    rows = sales.read("SalesData", "A2:D5")
    result = []
    for row in rows:
        code = row[0] if len(row) > 0 else ""
        name = row[1] if len(row) > 1 else ""
        qty = row[2] if len(row) > 2 and isinstance(row[2], (int, float)) else 0
        unit = row[3] if len(row) > 3 and isinstance(row[3], (int, float)) else 0
        result.append([code, name, qty, unit, qty * unit])
    out.write("ResultSheet", "A2", result)
