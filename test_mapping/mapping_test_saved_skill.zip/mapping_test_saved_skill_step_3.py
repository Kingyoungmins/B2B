# mapping_test_saved_skill step 3

def transform(ctx):
    codes = ctx.book("expected_codes.xlsx")
    out = ctx.book("expected_output.xlsx")
    code_rows = codes.read("CodeMap", "A2:B5")
    category_by_code = {}
    for row in code_rows:
        if row and row[0] not in (None, ""):
            category_by_code[str(row[0])] = row[1] if len(row) > 1 else ""
    result_codes = out.read("ResultSheet", "A2:A5")
    categories = []
    for row in result_codes:
        code = str(row[0]) if row and row[0] not in (None, "") else ""
        categories.append([category_by_code.get(code, "")])
    out.write("ResultSheet", "H2", categories)
