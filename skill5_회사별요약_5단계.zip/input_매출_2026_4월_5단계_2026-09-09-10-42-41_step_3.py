# input_매출_2026_4월_5단계_2026-09-09-10-42-41
# Step 3: "원가" 시트를 회사명별 원가 합계로 피벗해 새 시트로 만듭니다.
# Created: 2026-09-09T01:42:41.216Z
def transform(ctx):
    ctx.pivot("원가", group_by="회사명", value="원가", agg="sum", dest_name="회사별원가합계")