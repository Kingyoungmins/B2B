# input_매출_2026_4월_5단계_2026-09-09-10-42-41
# Step 1: "매출" 시트를 회사명별 금액 합계로 피벗해 새 시트로 만듭니다.
# Created: 2026-09-09T01:42:41.216Z
def transform(ctx):
    ctx.pivot("매출", group_by="회사명", value="금액", agg="sum", dest_name="회사별금액합계")