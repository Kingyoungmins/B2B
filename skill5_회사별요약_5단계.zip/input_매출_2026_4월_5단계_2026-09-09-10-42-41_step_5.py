# input_매출_2026_4월_5단계_2026-09-09-10-42-41
# Step 5: "회사별요약"의 매출(B)·원가(C)·마진(D) 열에 천 단위 쉼표 서식을 적용합니다(데이터 4행~합계 24행).
# Created: 2026-09-09T01:42:41.216Z
def transform(ctx):
    sheet = "회사별요약"
    last = ctx.last_row(sheet, col=1)
    ctx.set_number_format(sheet, f"B4:D{last}", "#,##0")