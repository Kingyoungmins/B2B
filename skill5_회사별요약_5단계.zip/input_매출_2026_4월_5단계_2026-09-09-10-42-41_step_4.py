# input_매출_2026_4월_5단계_2026-09-09-10-42-41
# Step 4: input_원가_2026_4월.xlsx의 "회사별원가합계" 값을 회사명에 맞춰 "회사별요약"의 원가(C) 열에 값으로 채웁니다. 합계/평균 요약 행(24행)은 제외합니다.
# Created: 2026-09-09T01:42:41.216Z
def transform(ctx):
    src = ctx.book("input_원가_2026_4월.xlsx")
    last_src = src.used_last_row("회사별원가합계")
    rows = src.read("회사별원가합계", f"A2:B{last_src}")
    cost = {ctx.normalize(r[0]): r[1] for r in rows if r[0] is not None}

    sheet = "회사별요약"
    hdr = 3
    last = ctx.last_row(sheet, col=1)
    names = ctx.read(sheet, f"A{hdr+1}:A{last}")
    out = []
    for r in names:
        nm = r[0]
        if nm is None or "합계" in str(nm):
            out.append([None])
        else:
            out.append([cost.get(ctx.normalize(nm), None)])

    ctx.write(sheet, f"C{hdr+1}", out, overwrite_formulas=True)